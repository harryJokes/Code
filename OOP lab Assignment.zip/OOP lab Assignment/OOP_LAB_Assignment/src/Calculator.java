
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

    public class Calculator implements ActionListener {
        JFrame f;
        JTextField number1, number2, res;
        JTextArea rArea;
        JButton addButton, subButton, mulButton, divButton;

        public Calculator() {


            f = new JFrame();
            f.setTitle("Arnob's Calculator");
            f.setLayout(new GridLayout(5, 2, 10, 10));
            f.setLocationRelativeTo(null);
            f.setSize(800, 500);
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            f.add(new JLabel("Arnob, enter the 1st number:"));
            number1 = new JTextField();
            f.add(number1);

            f.add(new JLabel("Arnob, enter the 2nd number:"));
            number2 = new JTextField();
            f.add(number2);

            addButton = new JButton("+   Arnob");
            subButton = new JButton("-   Arnob");
            mulButton = new JButton("*   Arnob");
            divButton = new JButton("/   Arnob");

            f.add(addButton);
            f.add(subButton);
            f.add(mulButton);
            f.add(divButton);

            addButton.addActionListener(this);
            subButton.addActionListener(this);
            mulButton.addActionListener(this);
            divButton.addActionListener(this);

            f.add(new JLabel("Arnob, the result is as follows:"));
            rArea = new JTextArea(2, 30);
            rArea.setEditable(false);
            f.add(rArea);

            f.setVisible(true);

        }

        public void actionPerformed(ActionEvent e) {


            double num1 = Double.parseDouble(number1.getText());
            double num2 = Double.parseDouble(number2.getText());
            double result = 0;
            if (e.getSource() == addButton) {
                result = num1 + num2;
                rArea.setText("Arnob , The Addition  is :" + result);
            } else if (e.getSource() == subButton) {
                result = num1 - num2;
                rArea.setText("Arnob , The Subtraction is :" + result);
            } else if (e.getSource() == mulButton) {
                result = num1 * num2;
                rArea.setText("Arnob , The Multiplication is :" + result);
            } else if (e.getSource() == divButton) {
                if (num2 > 0) {
                    result = num1 / num2;
                    rArea.setText("Arnob , The Division is :" + result);
                } else {
                    rArea.setText("Arnob ,The Division can't be determined due to an error!");

                }
            }

        }

        public static void main(String[] args) {
            new Calculator();

}
        }


